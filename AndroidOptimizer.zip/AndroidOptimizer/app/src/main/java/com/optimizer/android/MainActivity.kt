package com.optimizer.android

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main)
    private lateinit var logView: TextView
    private lateinit var scrollLog: ScrollView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnOptimize: Button
    private lateinit var btnRoot: Button
    private lateinit var statusText: TextView

    // ─── CATEGORIAS ─────────────────────────────────────────────────────────

    data class Cmd(val label: String, val cmd: String, val root: Boolean = false)
    data class Category(val name: String, val icon: String, val cmds: List<Cmd>)

    private val categories = listOf(

        Category("🎨 Animações", "UI mais fluida", listOf(
            Cmd("Desativar animação de janela",    "settings put global window_animation_scale 0"),
            Cmd("Desativar animação de transição", "settings put global transition_animation_scale 0"),
            Cmd("Desativar animação de duração",   "settings put global animator_duration_scale 0")
        )),

        Category("🧠 Memória / RAM", "Heap e LMK", listOf(
            Cmd("Heap inicial 16MB",     "setprop dalvik.vm.heapstartsize 16m"),
            Cmd("Heap máximo 512MB",     "setprop dalvik.vm.heapsize 512m"),
            Cmd("Heap crescimento 192MB","setprop dalvik.vm.heapgrowthlimit 192m"),
            Cmd("Heap utilização 0.75",  "setprop dalvik.vm.heaptargetutilization 0.75"),
            Cmd("Swappiness 10",         "echo 10 > /proc/sys/vm/swappiness", root = true),
            Cmd("Drop caches",           "echo 3 > /proc/sys/vm/drop_caches",  root = true),
            Cmd("LMK agressivo",         "echo 0,100,200,300,900,906 > /sys/module/lowmemorykiller/parameters/minfree", root = true)
        )),

        Category("⚡ CPU / I/O", "Scheduler e governor", listOf(
            Cmd("I/O scheduler deadline","echo deadline > /sys/block/mmcblk0/queue/scheduler", root = true),
            Cmd("Disco não rotacional",  "echo 0 > /sys/block/mmcblk0/queue/rotational",      root = true),
            Cmd("Nr requests 1024",      "echo 1024 > /sys/block/mmcblk0/queue/nr_requests",  root = true),
            Cmd("Add random off",        "echo 0 > /sys/block/mmcblk0/queue/add_random",      root = true),
            Cmd("CPU governor interactive","echo interactive > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor", root = true)
        )),

        Category("🌐 Rede", "TCP e DNS", listOf(
            Cmd("TCP BBR congestion",    "echo bbr > /proc/sys/net/ipv4/tcp_congestion_control", root = true),
            Cmd("TCP buffer RX",         "echo '4096 87380 16777216' > /proc/sys/net/ipv4/tcp_rmem", root = true),
            Cmd("TCP buffer TX",         "echo '4096 65536 16777216' > /proc/sys/net/ipv4/tcp_wmem", root = true),
            Cmd("DNS Google (seguro)",   "settings put global private_dns_mode hostname"),
            Cmd("DNS servidor Google",   "settings put global private_dns_specifier dns.google"),
            Cmd("Wi-Fi scan off",        "settings put global wifi_scan_always_enabled 0"),
            Cmd("Wi-Fi wakeup off",      "settings put global wifi_wakeup_enabled 0"),
            Cmd("Wi-Fi throttle off",    "settings put global wifi_scan_throttle_enabled 0")
        )),

        Category("🔋 Bateria / Doze", "Background e economia", listOf(
            Cmd("Ativar Doze",           "dumpsys deviceidle enable"),
            Cmd("Forçar Doze idle",      "dumpsys deviceidle force-idle"),
            Cmd("Background data off",   "settings put global background_data 0"),
            Cmd("NFC desativar",         "svc nfc disable")
        )),

        Category("🗃️ Compilação ART", "Abertura de apps mais rápida", listOf(
            Cmd("Compilar speed-profile","cmd package compile -m speed-profile -a")
        )),

        Category("🔇 Logs / Debug", "Libera CPU silencioso", listOf(
            Cmd("Suprimir ActivityManager", "setprop log.tag.ActivityManager SUPPRESS"),
            Cmd("Suprimir PackageManager",  "setprop log.tag.PackageManager SUPPRESS"),
            Cmd("Suprimir WindowManager",   "setprop log.tag.WindowManager SUPPRESS"),
            Cmd("Buffer log mínimo",        "logcat -G 256K"),
            Cmd("Perfetto off",             "setprop persist.traced.enable 0"),
            Cmd("ATrace off",               "setprop debug.atrace.tags.enableflags 0")
        )),

        Category("🧹 Limpeza", "Cache e trim", listOf(
            Cmd("Trim caches 1GB",       "pm trim-caches 1024M")
        ))
    )

    // ─── SWITCHES por categoria ──────────────────────────────────────────────
    private val switches = mutableMapOf<String, Boolean>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        logView     = findViewById(R.id.logView)
        scrollLog   = findViewById(R.id.scrollLog)
        progressBar = findViewById(R.id.progressBar)
        btnOptimize = findViewById(R.id.btnOptimize)
        btnRoot     = findViewById(R.id.btnRoot)
        statusText  = findViewById(R.id.statusText)

        val container = findViewById<LinearLayout>(R.id.categoryContainer)
        buildCategories(container)

        btnOptimize.setOnClickListener { scope.launch { runAll(rootOnly = false) } }
        btnRoot.setOnClickListener     { scope.launch { runAll(rootOnly = null) } }

        // Root check
        scope.launch(Dispatchers.IO) {
            val hasRoot = checkRoot()
            withContext(Dispatchers.Main) {
                statusText.text = if (hasRoot) "✅ Root detectado" else "⚠️ Sem root — comandos root serão pulados"
                btnRoot.isEnabled = hasRoot
            }
        }
    }

    // ─── UI ─────────────────────────────────────────────────────────────────

    private fun buildCategories(container: LinearLayout) {
        for (cat in categories) {
            switches[cat.name] = true

            val card = layoutInflater.inflate(R.layout.item_category, container, false)
            card.findViewById<TextView>(R.id.catName).text    = cat.name
            card.findViewById<TextView>(R.id.catSubtitle).text = cat.icon + " — " + cat.cmds.size + " comandos"

            val sw = card.findViewById<Switch>(R.id.catSwitch)
            sw.isChecked = true
            sw.setOnCheckedChangeListener { _, checked -> switches[cat.name] = checked }

            container.addView(card)
        }
    }

    // ─── EXECUTOR ───────────────────────────────────────────────────────────

    private suspend fun runAll(rootOnly: Boolean?) {
        setRunning(true)
        logView.text = ""
        log("=== Android Optimizer ===\n")

        val selected = categories.filter { switches[it.name] == true }
        val total    = selected.sumOf { it.cmds.size }.toFloat()
        var done     = 0

        withContext(Dispatchers.IO) {
            for (cat in selected) {
                withContext(Dispatchers.Main) { log("\n── ${cat.name} ──") }

                for (c in cat.cmds) {
                    if (rootOnly == false && c.root) {
                        withContext(Dispatchers.Main) { log("  [SKIP] ${c.label} (root)") }
                        done++
                        continue
                    }

                    val ok = exec(c.cmd, c.root)
                    done++

                    withContext(Dispatchers.Main) {
                        log("  [${if (ok) "✓" else "✗"}] ${c.label}")
                        progressBar.progress = (done / total * 100).toInt()
                    }
                }
            }
        }

        log("\n=== Concluído ===")
        setRunning(false)
    }

    private fun exec(cmd: String, root: Boolean): Boolean {
        return try {
            val process = if (root) {
                Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            } else {
                Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            }
            process.waitFor() == 0
        } catch (e: Exception) { false }
    }

    private fun checkRoot(): Boolean {
        return try {
            val p = Runtime.getRuntime().exec("su")
            p.outputStream.write("id\nexit\n".toByteArray())
            p.outputStream.flush()
            p.waitFor() == 0
        } catch (e: Exception) { false }
    }

    // ─── HELPERS ────────────────────────────────────────────────────────────

    private fun log(msg: String) {
        logView.append("$msg\n")
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setRunning(running: Boolean) {
        btnOptimize.isEnabled = !running
        btnRoot.isEnabled     = !running
        progressBar.visibility = if (running) View.VISIBLE else View.GONE
        if (running) progressBar.progress = 0
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
